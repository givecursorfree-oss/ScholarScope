/**
 * Auto-detect journal title / ISSN on SciMAGO and other research sites,
 * then ask the background worker to fetch DOAJ + OpenAlex.
 */
(function () {
  const ISSN_RE = /\b(\d{4})-?(\d{3}[\dXx])\b/g;
  let lastKey = "";
  let inflight = false;
  let debounceTimer = null;

  function host() {
    return location.hostname.replace(/^www\./, "");
  }

  function uniqIssns(text) {
    const out = [];
    const seen = new Set();
    let m;
    const re = new RegExp(ISSN_RE.source, "gi");
    while ((m = re.exec(text || "")) !== null) {
      const issn = `${m[1]}-${m[2].toUpperCase()}`;
      if (!seen.has(issn)) {
        seen.add(issn);
        out.push(issn);
      }
    }
    return out;
  }

  function textOf(el) {
    return (el?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function detectScimago() {
    // Journal profile / search result pages
    const h1 = document.querySelector("h1, .journaltitle, .title1, #journaltitle");
    let title = textOf(h1);
    if (title && /scimago|journal & country|rank/i.test(title) && title.length < 40) {
      title = "";
    }

    // Common SciMAGO table cells / detail blocks
    const detail = document.querySelector(
      ".journaldescription, .cellcontent, #journalinfo, .table_data"
    );
    const blob = `${title} ${textOf(detail)} ${textOf(document.body).slice(0, 8000)}`;
    const issns = uniqIssns(blob);

    // Search box value on SciMAGO
    const searchInput =
      document.querySelector("#searchinput") ||
      document.querySelector('input[name="q"]');
    const typed = (searchInput?.value || "").trim();
    const typedIsPlaceholder = /enter journal|issn|publisher/i.test(typed);

    // Ranking table: first visible journal title link
    if (!title) {
      const rowLink =
        document.querySelector("table tbody tr td a") ||
        document.querySelector(".ranking_body a") ||
        document.querySelector('a[href*="journalsearch.php"]');
      const t = textOf(rowLink);
      if (t && t.length > 2 && t.length < 200) title = t;
    }

    if (typed && !typedIsPlaceholder && typed.length > 2) {
      const typedIssn = uniqIssns(typed)[0];
      return {
        issn: typedIssn || issns[0] || null,
        title: typedIssn ? null : typed,
        detectText: `Detected from SciMAGO search: “${typed}”`,
      };
    }

    if (issns[0] || title) {
      return {
        issn: issns[0] || null,
        title: title || null,
        detectText: issns[0]
          ? `Detected ISSN ${issns[0]} on SciMAGO`
          : `Detected title on SciMAGO: “${title}”`,
      };
    }
    return null;
  }

  function detectGeneric() {
    const metaIssn =
      document.querySelector('meta[name="citation_issn"]')?.content ||
      document.querySelector('meta[name="dc.Identifier"][scheme="issn"]')
        ?.content ||
      document.querySelector('meta[name="ISSN"]')?.content;

    const citationTitle =
      document.querySelector('meta[name="citation_journal_title"]')?.content ||
      document.querySelector('meta[name="citation_title"]')?.content;

    const h1 = textOf(document.querySelector("h1"));
    const issns = uniqIssns(
      `${metaIssn || ""} ${textOf(document.body).slice(0, 12000)}`
    );

    const title =
      (citationTitle || "").trim() ||
      (h1 && h1.length < 180 ? h1 : "") ||
      null;

    if (metaIssn || issns[0] || title) {
      return {
        issn: uniqIssns(metaIssn || "")[0] || issns[0] || null,
        title: title,
        detectText: metaIssn
          ? `Detected citation ISSN ${uniqIssns(metaIssn)[0] || metaIssn}`
          : issns[0]
            ? `Detected ISSN ${issns[0]} on page`
            : `Detected page title: “${title}”`,
      };
    }
    return null;
  }

  function detectClarivate() {
    const h1 = textOf(document.querySelector("h1, .journal-title, [class*='JournalTitle']"));
    const metaIssn =
      document.querySelector('meta[name="citation_issn"]')?.content ||
      document.querySelector('meta[name="ISSN"]')?.content;
    const blob = `${h1} ${textOf(document.body).slice(0, 10000)}`;
    const issns = uniqIssns(`${metaIssn || ""} ${blob}`);
    const title =
      (h1 && h1.length > 2 && h1.length < 200 ? h1 : null) ||
      (document.querySelector("[data-testid='journal-title']") &&
        textOf(document.querySelector("[data-testid='journal-title']"))) ||
      null;
    if (issns[0] || title) {
      return {
        issn: uniqIssns(metaIssn || "")[0] || issns[0] || null,
        title: title,
        detectText: issns[0]
          ? `Detected ISSN ${issns[0]} on Clarivate / Web of Science`
          : `Detected journal on Clarivate: “${title}”`,
      };
    }
    return null;
  }

  function detectElsevier() {
    const citationTitle =
      document.querySelector('meta[name="citation_journal_title"]')?.content ||
      document.querySelector('meta[name="citation_title"]')?.content;
    const h1 = textOf(document.querySelector("h1"));
    const metaIssn =
      document.querySelector('meta[name="citation_issn"]')?.content ||
      document.querySelector('meta[name="citation_issn"]')?.getAttribute("content");
    const issns = uniqIssns(
      `${metaIssn || ""} ${textOf(document.body).slice(0, 12000)}`
    );
    const title = (citationTitle || "").trim() || (h1 && h1.length < 200 ? h1 : null);
    if (issns[0] || title) {
      return {
        issn: uniqIssns(metaIssn || "")[0] || issns[0] || null,
        title,
        detectText: issns[0]
          ? `Detected ISSN ${issns[0]} on Elsevier`
          : `Detected journal on Elsevier: “${title}”`,
      };
    }
    return null;
  }

  function detectTaylorFrancis() {
    const citationTitle =
      document.querySelector('meta[name="citation_journal_title"]')?.content ||
      document.querySelector('meta[name="dc.Title"]')?.content;
    const h1 = textOf(document.querySelector("h1"));
    const metaIssn = document.querySelector('meta[name="citation_issn"]')?.content;
    const issns = uniqIssns(
      `${metaIssn || ""} ${textOf(document.body).slice(0, 12000)}`
    );
    const title = (citationTitle || "").trim() || (h1 && h1.length < 200 ? h1 : null);
    if (issns[0] || title) {
      return {
        issn: uniqIssns(metaIssn || "")[0] || issns[0] || null,
        title,
        detectText: issns[0]
          ? `Detected ISSN ${issns[0]} on Taylor & Francis`
          : `Detected journal on Taylor & Francis: “${title}”`,
      };
    }
    return null;
  }

  function detect() {
    const h = host();
    if (h.includes("scimagojr.com")) return detectScimago();
    if (h.includes("clarivate.com") || h.includes("webofscience.com")) {
      return detectClarivate() || detectGeneric();
    }
    if (h.includes("elsevier.com") || h.includes("sciencedirect.com")) {
      return detectElsevier() || detectGeneric();
    }
    if (h.includes("tandfonline.com")) {
      return detectTaylorFrancis() || detectGeneric();
    }
    return detectGeneric();
  }

  function scrapePageApc() {
    try {
      const text = (document.body?.innerText || "").slice(0, 80000);
      const html = (document.body?.innerHTML || "").slice(0, 120000);
      const blob = `${text}\n${html}`;
      const feeContext =
        /article\s+processing|publication\s+fee|\bAPC\b|open\s+access\s+fee|publishing\s+charge|page\s+charge|colou?r\s+charge|submission\s+fee/i.test(
          blob
        );
      if (!feeContext) return null;

      const otherFeeLabels = [];
      const otherChecks = [
        [/page\s+charge/i, "Page charges"],
        [/colou?r\s+charge/i, "Color charges"],
        [/submission\s+fee|manuscript\s+fee/i, "Submission fee"],
        [/publishing\s+charge/i, "Publishing charges"],
        [/supplementary|supplement\s+fee/i, "Supplementary fees"],
      ];
      for (const [re, label] of otherChecks) {
        if (re.test(blob) && !otherFeeLabels.includes(label)) {
          otherFeeLabels.push(label);
        }
      }

      const re =
        /(?:CHF|USD|EUR|GBP|INR|US\$|\$|€|£)\s*(?:&nbsp;|\u00a0|\s)*([\d]{1,3}(?:,\d{3})*(?:\.\d{1,2})?|\d{3,6}(?:\.\d{1,2})?)/gi;
      const found = [];
      const seen = new Set();
      let m;
      while ((m = re.exec(blob)) !== null) {
        const amount = Number(String(m[1]).replace(/,/g, ""));
        if (!Number.isFinite(amount) || amount < 50 || amount > 50000) continue;
        const token = m[0].toUpperCase();
        let currency = "USD";
        if (token.includes("CHF")) currency = "CHF";
        else if (token.includes("EUR") || token.includes("€")) currency = "EUR";
        else if (token.includes("GBP") || token.includes("£")) currency = "GBP";
        else if (token.includes("INR")) currency = "INR";
        const key = `${currency}:${amount}`;
        if (seen.has(key)) continue;
        seen.add(key);
        found.push({ price: amount, currency });
        if (found.length >= 4) break;
      }
      if (!found.length && !otherFeeLabels.length) return null;
      return {
        apc: found,
        otherFeeLabels,
        sourceUrl: location.href,
      };
    } catch {
      return null;
    }
  }

  function lookup(payload, detectText) {
    const key = `${payload.issn || ""}|${(payload.title || "").toLowerCase()}`;
    if (!payload.issn && !payload.title) return;
    if (key === lastKey && !payload.force) return;
    if (inflight) return;

    lastKey = key;
    inflight = true;
    window.JournalInsightPanel?.showLoading(detectText);

    const pageApc = scrapePageApc();
    const fullPayload = pageApc ? { ...payload, pageApc } : payload;

    chrome.runtime.sendMessage(
      { type: "LOOKUP_JOURNAL", payload: fullPayload },
      (response) => {
        inflight = false;
        if (chrome.runtime.lastError) {
          window.JournalInsightPanel?.showError(
            chrome.runtime.lastError.message,
            detectText
          );
          return;
        }
        window.JournalInsightPanel?.showResult(response, detectText);
      }
    );
  }

  function runAuto(force = false) {
    const found = detect();
    if (!found) return;
    lookup(
      {
        issn: found.issn,
        title: found.title,
        force,
        locale: navigator.language || "en-US",
        languages:
          typeof navigator.languages !== "undefined" && navigator.languages.length
            ? [...navigator.languages]
            : [navigator.language || "en-US"],
        timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "",
      },
      found.detectText
    );
  }

  function schedule() {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => runAuto(false), 450);
  }

  window.addEventListener("ji:refresh", () => {
    lastKey = "";
    runAuto(true);
  });

  // Watch search inputs (SciMAGO)
  document.addEventListener(
    "change",
    (e) => {
      if (e.target?.matches?.("input, select")) schedule();
    },
    true
  );
  document.addEventListener(
    "keyup",
    (e) => {
      if (e.target?.matches?.("#searchinput, input[name='q']")) schedule();
    },
    true
  );

  const mo = new MutationObserver(() => schedule());
  mo.observe(document.documentElement, {
    childList: true,
    subtree: true,
  });

  // Initial
  window.JournalInsightPanel?.ensure();
  setTimeout(() => runAuto(true), 200);
})();
