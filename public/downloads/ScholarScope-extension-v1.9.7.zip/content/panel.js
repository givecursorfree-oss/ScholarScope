/**
 * Floating panel UI — ScholarScope
 */
(function () {
  if (window.JournalInsightPanel) return;

  let root = null;
  let bodyEl = null;
  let collapsed = false;
  let currentLookupKey = "";

  const LOGO_URL = chrome.runtime.getURL("brand/logo.png");

  const ICONS = {
    logo: `<img class="ji-logo" src="${LOGO_URL}" width="22" height="22" alt="" />`,
    fab: `<img class="ji-fab-logo" src="${LOGO_URL}" width="44" height="44" alt="ScholarScope" />`,
    refresh: `<svg class="ji-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="M21 12a9 9 0 1 1-2.64-6.36"/><path d="M21 3v6h-6"/></svg>`,
    minimize: `<svg class="ji-icon-svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="m6 9 6 6 6-6"/></svg>`,
  };

  function openExternal(url) {
    if (!url) return;
    try {
      chrome.runtime.sendMessage({ type: "OPEN_URL", url }, () => {
        if (chrome.runtime.lastError) {
          window.open(url, "_blank", "noopener,noreferrer");
        }
      });
    } catch {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  }

  function ensureFonts() {
    if (document.getElementById("ji-fonts")) return;
    const pre1 = document.createElement("link");
    pre1.rel = "preconnect";
    pre1.href = "https://fonts.googleapis.com";
    pre1.id = "ji-fonts-preconnect";
    const pre2 = document.createElement("link");
    pre2.rel = "preconnect";
    pre2.href = "https://fonts.gstatic.com";
    pre2.crossOrigin = "anonymous";
    const link = document.createElement("link");
    link.id = "ji-fonts";
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@500;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap";
    document.documentElement.append(pre1, pre2, link);
  }

  function ensureDom() {
    if (root) return root;
    ensureFonts();

    const fab = document.createElement("button");
    fab.className = "ji-fab";
    fab.id = "ji-fab";
    fab.title = "ScholarScope";
    fab.setAttribute("aria-label", "Open ScholarScope");
    fab.setAttribute("aria-expanded", "true");
    fab.innerHTML = ICONS.fab;
    fab.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      collapsed = !collapsed;
      root.classList.toggle("ji-hidden", collapsed);
      fab.setAttribute("aria-expanded", String(!collapsed));
    });
    document.documentElement.appendChild(fab);

    root = document.createElement("div");
    root.id = "ji-root";
    root.setAttribute("role", "complementary");
    root.setAttribute("aria-label", "ScholarScope journal brief");
    root.innerHTML = `
      <div class="ji-card">
        <div class="ji-header">
          <div class="ji-brand">
            ${ICONS.logo}
            <span class="ji-brand-name">ScholarScope</span>
          </div>
          <div class="ji-header-actions" role="toolbar" aria-label="Panel actions">
            <button class="ji-icon-btn" type="button" data-ji="refresh" title="Refresh brief" aria-label="Refresh brief">
              ${ICONS.refresh}
              <span class="ji-icon-label">Refresh</span>
            </button>
            <button class="ji-icon-btn" type="button" data-ji="close" title="Minimize panel" aria-label="Minimize panel">
              ${ICONS.minimize}
              <span class="ji-icon-label">Hide</span>
            </button>
          </div>
        </div>
        <div class="ji-body">
          <div id="ji-content" class="ji-status">
            <div class="ji-empty">
              <div class="ji-empty-title">Waiting for a journal page</div>
              <div class="ji-empty-body">ScholarScope detects the journal here. Search manually from the toolbar popup.</div>
            </div>
          </div>
        </div>
      </div>
    `;
    document.documentElement.appendChild(root);
    bodyEl = root.querySelector("#ji-content");

    root.addEventListener(
      "click",
      (e) => {
        const a = e.target.closest?.("a[href]");
        if (a && root.contains(a)) {
          e.preventDefault();
          e.stopPropagation();
          openExternal(a.href);
        }
      },
      true
    );
    root.addEventListener("click", (e) => {
      e.stopPropagation();
    });

    root.querySelector('[data-ji="close"]').addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      collapsed = true;
      root.classList.add("ji-hidden");
      fab.setAttribute("aria-expanded", "false");
    });

    root.querySelector('[data-ji="refresh"]').addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      const btn = e.currentTarget;
      btn.classList.add("is-spinning");
      window.dispatchEvent(new CustomEvent("ji:refresh"));
      setTimeout(() => btn.classList.remove("is-spinning"), 600);
    });

    return root;
  }

  function escapeHtml(s) {
    return String(s ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function escapeAttr(s) {
    return escapeHtml(s).replace(/'/g, "&#39;");
  }

  function href(url, label, className = "ji-a") {
    const text = escapeHtml(label);
    if (!url) return `<span class="${className}">${text}</span>`;
    return `<a class="${className}" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">${text}</a>`;
  }

  function chipLink(url, label, extraClass = "") {
    const cls = `ji-chip ${extraClass}`.trim();
    if (!url) return `<span class="${cls}">${escapeHtml(label)}</span>`;
    return `<a class="${cls} ji-chip-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
  }

  function subjectItems(d, o) {
    const fromDoaj = (d?.subjects || []).map((name) => ({
      name,
      url: `https://openalex.org/sources?search=${encodeURIComponent(name)}`,
    }));
    const fromOa = (o?.topics || []).map((t) =>
      typeof t === "string"
        ? {
            name: t,
            url: `https://openalex.org/sources?search=${encodeURIComponent(t)}`,
          }
        : { name: t.name, url: t.url }
    );
    const seen = new Set();
    const out = [];
    for (const item of [...fromDoaj, ...fromOa]) {
      if (!item?.name || seen.has(item.name)) continue;
      seen.add(item.name);
      out.push(item);
    }
    return out;
  }

  function renderLoading(detectText) {
    ensureDom();
    collapsed = false;
    root.classList.remove("ji-hidden");
    document.getElementById("ji-fab")?.setAttribute("aria-expanded", "true");
    bodyEl.innerHTML = `
      ${detectText ? `<div class="ji-detect">${escapeHtml(detectText)}</div>` : ""}
      <div class="ji-skeleton" aria-busy="true" aria-live="polite">
        <div class="ji-skel ji-skel-line" style="width:38%"></div>
        <div class="ji-skel ji-skel-title"></div>
        <div class="ji-skel ji-skel-line" style="width:62%"></div>
        <div class="ji-skel-row">
          <div class="ji-skel ji-skel-block"></div>
          <div class="ji-skel ji-skel-block"></div>
        </div>
        <p class="ji-skel-label">Fetching journal data…</p>
      </div>
    `;
  }

  function renderError(err, detectText) {
    ensureDom();
    collapsed = false;
    root.classList.remove("ji-hidden");
    bodyEl.innerHTML = `
      ${detectText ? `<div class="ji-detect">${escapeHtml(detectText)}</div>` : ""}
      <div class="ji-error" role="alert">
        <strong>Couldn’t load this journal</strong>
        <p>${escapeHtml(err || "Lookup failed")}</p>
        <p class="ji-error-hint">Refresh, or search from the toolbar popup.</p>
      </div>
    `;
  }

  function localCurrencyBlockHtml(apcDisplay) {
    const amount = apcDisplay?.localAmountText;
    const place = apcDisplay?.localPlace;
    const localLine = apcDisplay?.localLine || "";
    const pending = apcDisplay?.localPending;

    if (amount) {
      const kicker = place
        ? `Approx. in ${place}`
        : "Approx. in your currency";
      return `
        <div class="ji-price-local-block" id="ji-price-local" aria-live="polite">
          <span class="ji-price-local-kicker">${escapeHtml(kicker)}</span>
          <span class="ji-apc-amount ji-apc-local">${escapeHtml(amount)}</span>
          <span class="ji-price-local-note">Today’s rate via Frankfurter · not the publisher invoice</span>
        </div>`;
    }
    if (localLine) {
      const warn = localLine.includes("unavailable");
      return `<p class="ji-price-local${warn ? " ji-price-local-warn" : ""}" id="ji-price-local">${escapeHtml(localLine)}</p>`;
    }
    if (pending) {
      return `<p class="ji-price-local ji-price-local-pending" id="ji-price-local" aria-live="polite">Converting to your currency…</p>`;
    }
    return "";
  }

  function apcBlockHtml(data, apcUrl) {
    const hero =
      data.apcDisplay?.heroText ||
      data.apcDisplay?.primaryText ||
      "Not listed in DOAJ";
    const secondary = data.apcDisplay?.secondaryText || "";
    const localHtml = localCurrencyBlockHtml(data.apcDisplay);
    const isAmount =
      /\d/.test(hero) && !/not listed|no article|hybrid|subscription/i.test(hero);

    let primaryInner;
    if (isAmount) {
      const mount = `data-ss-apc-shimmer data-apc-text="${escapeAttr(hero)}"`;
      if (apcUrl) {
        primaryInner = `<span class="ji-apc-mount" ${mount} data-apc-href="${escapeAttr(apcUrl)}" data-apc-class="ji-a ji-apc-amount"></span>`;
      } else {
        primaryInner = `<span class="ji-apc-mount" ${mount} data-apc-class="ji-apc-amount"></span>`;
      }
    } else {
      const msgCls = "ji-apc-message";
      const label = /not listed/i.test(hero) ? "Not listed in DOAJ" : hero;
      primaryInner = apcUrl
        ? `<p class="${msgCls}">${href(apcUrl, label, "ji-a")}</p>`
        : `<p class="${msgCls}">${escapeHtml(label)}</p>`;
      if (/not listed|hybrid|subscription/i.test(hero)) {
        primaryInner += `<p class="ji-apc-hint">May be hybrid or subscription-only. Confirm on the publisher site.</p>`;
      } else if (/no article processing/i.test(hero)) {
        primaryInner += `<p class="ji-apc-hint">This journal reports no APC in DOAJ.</p>`;
      }
    }
    const secondaryHtml = secondary
      ? `<p class="ji-price-alt">Also listed: ${escapeHtml(secondary)}</p>`
      : "";
    const sourceBadge = data.apcDisplay?.sourceBadge
      ? `<span class="ji-apc-badge">${escapeHtml(data.apcDisplay.sourceBadge)}</span>`
      : "";
    const sourceHint = data.apcDisplay?.sourceHint
      ? `<p class="ji-apc-hint">${escapeHtml(data.apcDisplay.sourceHint)}</p>`
      : "";
    const clickHint =
      isAmount && apcUrl
        ? `<p class="ji-apc-hint">Click the price to open the fee source page.</p>`
        : "";
    const ui = globalThis.ScholarScopeUi;
    const otherHtml = ui?.otherFeesBlock
      ? ui.otherFeesBlock(data.otherFees, "ji")
      : "";
    return `
      <h4 class="ji-bento-kicker">Article processing charge</h4>
      ${sourceBadge}
      <div class="ji-price-hero">
        ${primaryInner}
      </div>
      ${secondaryHtml}
      ${localHtml}
      ${sourceHint}
      ${clickHint}
      ${otherHtml}
    `;
  }

  function feesBentoHtml(data, d, o, apcUrl, ctx) {
    const ui = globalThis.ScholarScopeUi;
    const indexTile = ui
      ? ui.indexingPublicationTile(d, o, ctx, "ji")
      : `<p class="ji-prose ji-prose-muted">Indexing data unavailable.</p>`;
    return `
      <div class="ji-fees-bento">
        <article class="ji-bento-tile ji-bento-apc">${apcBlockHtml(data, apcUrl)}</article>
        <article class="ji-bento-tile ji-bento-index">${indexTile}</article>
      </div>
    `;
  }

  function applyLocalLine(lookupKey, message) {
    if (lookupKey && lookupKey !== currentLookupKey) return;
    const payload =
      message && typeof message === "object"
        ? message
        : { localLine: message };
    const el = document.getElementById("ji-price-local");
    if (!el) return;

    if (payload.localAmountText) {
      const block = localCurrencyBlockHtml({
        localAmountText: payload.localAmountText,
        localPlace: payload.localPlace,
      });
      el.outerHTML = block;
      return;
    }

    const localLine =
      payload.localLine ||
      "Exchange rate unavailable. Open ScholarScope popup → pick a display currency.";
    el.textContent = localLine;
    el.classList.remove("ji-price-local-pending");
    if (!payload.localLine || localLine.includes("unavailable")) {
      el.classList.add("ji-price-local-warn");
    } else {
      el.classList.remove("ji-price-local-warn");
    }
  }

  function freshnessHtml(cached) {
    const cls = cached ? "is-cached" : "is-live";
    const label = cached ? "Cached" : "Live data";
    return `<span class="ji-freshness" role="status"><span class="ji-freshness-dot ${cls}" aria-hidden="true"></span>${label}</span>`;
  }

  function renderResult(data, detectText) {
    ensureDom();
    collapsed = false;
    root.classList.remove("ji-hidden");
    globalThis.ScholarScopePriceShimmer?.unmountAllApcPrices?.(bodyEl);

    if (!data?.ok) {
      renderError((data?.errors || []).join("; ") || "No match", detectText);
      return;
    }

    const d = data.doaj;
    const o = data.openalex;
    const journalUrl =
      data.journalUrl || data.homepage || d?.journalUrl || o?.homepage || data.scimagoUrl;
    const issnUrl =
      data.issnUrl ||
      (data.issn ? `https://portal.issn.org/resource/ISSN/${data.issn}` : null);
    const publisherUrl =
      data.publisherUrl ||
      o?.publisherUrl ||
      (data.publisher
        ? `https://www.scimagojr.com/journalsearch.php?q=${encodeURIComponent(data.publisher)}`
        : null);
    const openAlexUrl = o?.openAlexUrl || null;
    const doajUrl = data.doajUrl || d?.doajUrl || null;
    // Price click → page where that fee was sourced (DOAJ/OpenAlex/publisher fee page).
    const feeSource = data.apcDisplay?.feeSource || null;
    const apcUrl =
      data.apcDisplay?.sourceUrl ||
      data.publisherApc?.sourceUrl ||
      d?.apcUrl ||
      d?.oaStatementUrl ||
      data.otherFees?.feeUrl ||
      (feeSource === "doaj" ? doajUrl : null) ||
      (feeSource === "openalex" ? openAlexUrl : null) ||
      null;

    const bentoCtx = {
      doajUrl,
      scimagoUrl: data.scimagoUrl,
      openAlexUrl,
      issnUrl,
      indexingRows: data.indexing?.rows || [],
      publisherApcUrl:
        data.publisherApc?.sourceUrl || d?.apcUrl || d?.oaStatementUrl || null,
    };

    const licenses = (d?.licenses || []).filter((l) => l?.type);
    const subjects = subjectItems(d, o);

    const cited =
      o?.meanCitedness2yr != null
        ? Number(o.meanCitedness2yr).toFixed(2)
        : "—";

    const metricsHref = openAlexUrl || data.scimagoUrl;

    currentLookupKey = data.lookupKey || "";

    const ui = globalThis.ScholarScopeUi;
    const oaHtml = ui
      ? ui.openAccessBody(d, o, doajUrl, openAlexUrl, licenses, "ji")
      : `<p class="ji-prose ji-prose-muted">Access details could not be loaded. Reload the extension.</p>`;
    const subjectsHtml = ui
      ? ui.subjectLine(subjects, "ji", 10)
      : `<p class="ji-prose ji-prose-muted">Subjects could not be loaded. Reload the extension.</p>`;

    bodyEl.innerHTML = `
      ${detectText ? `<div class="ji-detect">${escapeHtml(detectText)}</div>` : ""}
      <div class="ji-panel-card">
        <div class="ji-eyebrow">Publishing brief</div>
        <h2 class="ji-title">${href(journalUrl, data.title || "Journal", "ji-a ji-title-link")}</h2>
        <div class="ji-meta">
          ${
            data.issn
              ? href(issnUrl, `ISSN ${data.issn}`, "ji-a ji-mono")
              : ""
          }
          ${href(publisherUrl, data.publisher || "Publisher unknown", "ji-a")}
          ${freshnessHtml(data.cached)}
        </div>
      </div>

      <div class="ji-stack">
        <div class="ji-section ji-section-fees">
          ${feesBentoHtml(data, d, o, apcUrl, bentoCtx)}
        </div>

        <div class="ji-section">
          <h3 class="ji-section-head">Access &amp; license</h3>
          ${oaHtml}
        </div>

        <div class="ji-section ji-section-subjects">
          <h3 class="ji-section-head">Subjects</h3>
          ${subjectsHtml}
        </div>

        <div class="ji-section">
          <h3 class="ji-section-head">Impact metrics</h3>
          <div class="ji-metric-row">
            <a class="ji-metric ji-metric-link" href="${escapeAttr(metricsHref)}" target="_blank" rel="noopener noreferrer">
              <div class="ji-metric-k">2yr mean citedness</div>
              <div class="ji-metric-v">${escapeHtml(cited)}</div>
            </a>
            <a class="ji-metric ji-metric-link" href="${escapeAttr(metricsHref)}" target="_blank" rel="noopener noreferrer">
              <div class="ji-metric-k">h-index</div>
              <div class="ji-metric-v">${o?.hIndex != null ? escapeHtml(String(o.hIndex)) : "—"}</div>
            </a>
          </div>
          <div class="ji-value" style="margin-top:10px">
            ${o?.i10Index != null ? `i10 ${o.i10Index}` : ""}
            <span class="ji-muted"> · not Clarivate IF</span>
          </div>
        </div>

        <div class="ji-links">
          <a class="primary" href="${escapeAttr(data.scimagoUrl)}" target="_blank" rel="noopener noreferrer">View SJR on SCImago</a>
          ${
            apcUrl
              ? `<a href="${escapeAttr(apcUrl)}" target="_blank" rel="noopener noreferrer">Publisher APC page</a>`
              : ""
          }
          ${
            journalUrl
              ? `<a href="${escapeAttr(journalUrl)}" target="_blank" rel="noopener noreferrer">Journal homepage</a>`
              : ""
          }
          ${
            openAlexUrl
              ? `<a href="${escapeAttr(openAlexUrl)}" target="_blank" rel="noopener noreferrer">OpenAlex record</a>`
              : ""
          }
          ${
            doajUrl
              ? `<a href="${escapeAttr(doajUrl)}" target="_blank" rel="noopener noreferrer">DOAJ record</a>`
              : ""
          }
        </div>

        <div class="ji-note">
          Impact figures are OpenAlex estimates, not Clarivate Journal Impact Factor. Fees from publisher and DOAJ when listed.
        </div>
      </div>
    `;
    globalThis.ScholarScopePriceShimmer?.mountAllApcPrices?.(bodyEl);
  }

  window.JournalInsightPanel = {
    showLoading: renderLoading,
    showError: renderError,
    showResult: renderResult,
    applyLocalLine,
    ensure: ensureDom,
  };

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type !== "APC_LOCAL_LINE") return;
    applyLocalLine(message.lookupKey, message);
  });

  ensureDom();
})();
