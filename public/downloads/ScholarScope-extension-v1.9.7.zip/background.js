import { lookupJournal, normalizeIssn } from "./lib/api.js";
import {
  apcDisplaySync,
  apcLocalConversion,
  FX_TIMEOUT_MS,
} from "./lib/apc-display.js";
import { resolveLookupPrefs } from "./lib/prefs.js";

const cache = new Map();
const CACHE_TTL_MS = 1000 * 60 * 30;
const pendingLocal = new Map();

function cacheKey({ issn, title }) {
  return `${normalizeIssn(issn) || ""}|${(title || "").toLowerCase().trim()}`;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === "LOOKUP_JOURNAL") {
    handleLookup(message.payload, sender)
      .then((result) => {
        sendResponse(result);
        if (result?.apcDisplay?.localPending && result.lookupKey) {
          void deliverLocalLine(result.lookupKey, sender);
        }
      })
      .catch((err) =>
        sendResponse({
          ok: false,
          errors: [String(err?.message || err)],
        })
      );
    return true;
  }

  if (message?.type === "OPEN_URL") {
    const url = String(message.url || "").trim();
    if (/^https?:\/\//i.test(url)) {
      chrome.tabs.create({ url });
      sendResponse({ ok: true });
    } else {
      sendResponse({ ok: false, error: "Invalid URL" });
    }
    return false;
  }

  if (message?.type === "PING") {
    sendResponse({ ok: true, version: "1.9.7", name: "ScholarScope" });
    return false;
  }

  return false;
});

async function attachApcDisplayFast(data, prefs, cached, lookupKey) {
  if (!data?.ok) {
    return { ...data, cached: Boolean(cached), lookupKey };
  }
  const apcDisplay = apcDisplaySync({
    doaj: data.doaj,
    openalex: data.openalex,
    publisherApc: data.publisherApc,
    locale: prefs.locale,
    currencyOverride: prefs.currencyOverride,
    timeZone: prefs.timeZone,
    languages: prefs.languages,
  });

  const job = {
    usdAmount: apcDisplay.usdAmount,
    fxAmount: apcDisplay.fxAmount,
    fxCurrency: apcDisplay.fxCurrency,
    locale: prefs.locale,
    currencyOverride: prefs.currencyOverride,
    timeZone: prefs.timeZone,
    languages: prefs.languages,
  };

  let { usdAmount: _u, fxAmount: _fa, fxCurrency: _fc, ...publicApc } = apcDisplay;

  if (publicApc.localPending && (job.fxAmount != null || job.usdAmount != null)) {
    const quick = await Promise.race([
      apcLocalConversion(job),
      new Promise((resolve) =>
        setTimeout(() => resolve("__timeout__"), 2800)
      ),
    ]);
    if (quick && quick !== "__timeout__") {
      publicApc.localLine = quick.line ?? null;
      publicApc.localAmountText = quick.amountText ?? null;
      publicApc.localPlace = quick.place ?? null;
      publicApc.localPending = false;
    } else {
      pendingLocal.set(lookupKey, job);
    }
  }

  return {
    ...data,
    cached: Boolean(cached),
    lookupKey,
    apcDisplay: publicApc,
  };
}

async function deliverLocalLine(lookupKey, sender) {
  const job = pendingLocal.get(lookupKey);
  if (!job) return;
  pendingLocal.delete(lookupKey);

  const local = await Promise.race([
    apcLocalConversion(job),
    new Promise((resolve) =>
      setTimeout(() => resolve(null), FX_TIMEOUT_MS)
    ),
  ]);

  const payload = {
    type: "APC_LOCAL_LINE",
    lookupKey,
    localLine: local?.line ?? null,
    localAmountText: local?.amountText ?? null,
    localPlace: local?.place ?? null,
  };

  if (sender.tab?.id != null) {
    try {
      await chrome.tabs.sendMessage(sender.tab.id, payload);
    } catch {
      /* tab may not have content script */
    }
  } else {
    try {
      await chrome.runtime.sendMessage(payload);
    } catch {
      /* no listeners */
    }
  }
}

async function handleLookup(payload = {}, _sender) {
  const issn = normalizeIssn(payload.issn);
  const title = (payload.title || "").trim() || null;
  const prefs = await resolveLookupPrefs(payload);
  if (!issn && !title) {
    return { ok: false, errors: ["Provide an ISSN or journal title"] };
  }

  const key = cacheKey({ issn, title });
  const hit = cache.get(key);
  // Skip cache when page scraped a live APC/homepage, or force refresh
  if (
    hit &&
    Date.now() - hit.ts < CACHE_TTL_MS &&
    !payload.force &&
    !payload.pageApc &&
    !payload.pageHomepage
  ) {
    return attachApcDisplayFast(hit.data, prefs, true, key);
  }

  const data = await lookupJournal({
    issn,
    title,
    pageApc: payload.pageApc || null,
    pageHomepage: payload.pageHomepage || null,
  });
  cache.set(key, { ts: Date.now(), data });
  return attachApcDisplayFast(data, prefs, false, key);
}
