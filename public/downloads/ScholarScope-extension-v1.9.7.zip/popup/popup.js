import { LOCAL_LINE_FAILED } from "../lib/apc-display.js";
import {
  CURRENCY_OPTIONS,
  getDisplayCurrencyOverride,
  setDisplayCurrencyOverride,
} from "../lib/prefs.js";
import { mountAllApcPrices } from "../dist/price-shimmer.esm.js";

const form = document.getElementById("form");
const q = document.getElementById("q");
const status = document.getElementById("status");
const out = document.getElementById("out");
const displayCurrency = document.getElementById("displayCurrency");

let lastLookupKey = "";
let lastPayload = null;

function clientContext() {
  const langs =
    typeof navigator.languages !== "undefined" && navigator.languages.length
      ? [...navigator.languages]
      : [navigator.language || "en-US"];
  return {
    locale: navigator.language || "en-US",
    languages: langs,
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "",
  };
}

function buildPayload(raw) {
  const issnMatch = raw.match(/\d{4}-?\d{3}[\dXx]/i);
  const currency = displayCurrency?.value || "";
  const base = {
    ...clientContext(),
    displayCurrency: currency,
  };
  return issnMatch
    ? { issn: issnMatch[0], title: null, ...base }
    : { issn: null, title: raw, ...base };
}

function runLookup(payload) {
  lastPayload = payload;
  status.textContent = "ScholarScope · loading…";
  out.hidden = true;

  chrome.runtime.sendMessage({ type: "LOOKUP_JOURNAL", payload }, (response) => {
    if (chrome.runtime.lastError) {
      status.innerHTML = `<div class="error">${escapeHtml(
        chrome.runtime.lastError.message
      )}</div>`;
      return;
    }
    render(response);
  });
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  const raw = q.value.trim();
  if (!raw) return;
  runLookup(buildPayload(raw));
});

displayCurrency?.addEventListener("change", async () => {
  await setDisplayCurrencyOverride(displayCurrency.value);
  if (lastPayload && !out.hidden) {
    runLookup({ ...lastPayload, displayCurrency: displayCurrency.value });
  }
});

async function initCurrencySelect() {
  if (!displayCurrency) return;
  displayCurrency.innerHTML = CURRENCY_OPTIONS.map(
    (o) =>
      `<option value="${escapeAttr(o.value)}">${escapeHtml(o.label)}</option>`
  ).join("");
  const saved = await getDisplayCurrencyOverride();
  displayCurrency.value = saved || "";
}

initCurrencySelect();

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "APC_LOCAL_LINE") return;
  if (message.lookupKey !== lastLookupKey) return;
  applyPopupLocalLine(message);
});

function applyPopupLocalLine(message) {
  const el = document.getElementById("price-local");
  if (!el) return;

  if (message?.localAmountText) {
    const kicker = message.localPlace
      ? `Approx. in ${message.localPlace}`
      : "Approx. in your currency";
    el.outerHTML = `
      <div class="price-local-block" id="price-local" aria-live="polite">
        <span class="price-local-kicker">${escapeHtml(kicker)}</span>
        <span class="price-hero price-local-amount">${escapeHtml(message.localAmountText)}</span>
        <span class="price-local-note">Today’s rate via Frankfurter</span>
      </div>`;
    return;
  }

  const localLine = message?.localLine;
  if (localLine) {
    if (el.tagName === "DIV") {
      el.outerHTML = `<p class="price-local" id="price-local">${escapeHtml(localLine)}</p>`;
      return;
    }
    el.textContent = localLine;
    el.classList.remove("price-local-pending");
    if (localLine === LOCAL_LINE_FAILED) {
      el.classList.add("price-local-warn");
    } else {
      el.classList.remove("price-local-warn");
    }
    return;
  }
  if (el.tagName === "P") {
    el.textContent = LOCAL_LINE_FAILED;
    el.classList.remove("price-local-pending");
    el.classList.add("price-local-warn");
  }
}

function escapeHtml(s) {
  return String(s ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function escapeAttr(s) {
  return escapeHtml(s).replace(/'/g, "&#39;");
}

function href(url, label, className = "a") {
  const text = escapeHtml(label);
  if (!url) return `<span class="${className}">${text}</span>`;
  return `<a class="${className}" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">${text}</a>`;
}

function chipLink(url, label, extraClass = "") {
  const cls = `chip ${extraClass}`.trim();
  if (!url) return `<span class="${cls}">${escapeHtml(label)}</span>`;
  return `<a class="${cls} chip-link" href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer">${escapeHtml(label)}</a>`;
}

function subjectItems(d, o) {
  const fromDoaj = (d?.subjects || []).map((name) => ({
    name,
    url: `https://openalex.org/sources?search=${encodeURIComponent(name)}`,
  }));
  const fromOa = (o?.topics || []).map((t) =>
    typeof t === "string"
      ? {
          name: t,
          url: `https://openalex.org/sources?search=${encodeURIComponent(t)}`,
        }
      : { name: t.name, url: t.url }
  );
  const seen = new Set();
  const out = [];
  for (const item of [...fromDoaj, ...fromOa]) {
    if (!item?.name || seen.has(item.name)) continue;
    seen.add(item.name);
    out.push(item);
  }
  return out;
}

function apcLocalHtml(data) {
  const amount = data.apcDisplay?.localAmountText;
  const place = data.apcDisplay?.localPlace;
  const localLine = data.apcDisplay?.localLine || "";
  if (amount) {
    const kicker = place ? `Approx. in ${place}` : "Approx. in your currency";
    return `
      <div class="price-local-block" id="price-local" aria-live="polite">
        <span class="price-local-kicker">${escapeHtml(kicker)}</span>
        <span class="price-hero price-local-amount">${escapeHtml(amount)}</span>
        <span class="price-local-note">Today’s rate via Frankfurter</span>
      </div>`;
  }
  if (localLine) {
    return `<p class="price-local" id="price-local">${escapeHtml(localLine)}</p>`;
  }
  if (data.apcDisplay?.localPending) {
    return `<p class="price-local price-local-pending" id="price-local" aria-live="polite">Converting to your currency…</p>`;
  }
  return "";
}

function render(data) {
  if (!data?.ok) {
    status.innerHTML = `<div class="error">${escapeHtml(
      (data?.errors || ["No match"]).join("; ")
    )}</div>`;
    if (data?.scimagoUrl) {
      status.innerHTML += `<div class="links" style="margin:8px 16px"><a class="primary" href="${escapeAttr(
        data.scimagoUrl
      )}" target="_blank" rel="noopener noreferrer">Search on SCImago</a></div>`;
    }
    out.hidden = true;
    return;
  }

  lastLookupKey = data.lookupKey || "";
  status.textContent = data.cached ? "Cached brief" : "Live brief";
  const d = data.doaj;
  const o = data.openalex;
  const journalUrl =
    data.journalUrl || data.homepage || d?.journalUrl || o?.homepage || data.scimagoUrl;
  const issnUrl =
    data.issnUrl ||
    (data.issn ? `https://portal.issn.org/resource/ISSN/${data.issn}` : null);
  const publisherUrl =
    data.publisherUrl ||
    o?.publisherUrl ||
    (data.publisher
      ? `https://www.scimagojr.com/journalsearch.php?q=${encodeURIComponent(data.publisher)}`
      : null);
  const openAlexUrl = o?.openAlexUrl || null;
  const doajUrl = data.doajUrl || d?.doajUrl || null;

  const apcHero =
    data.apcDisplay?.heroText ||
    data.apcDisplay?.primaryText ||
    "Not listed in DOAJ";
  const apcSecondary = data.apcDisplay?.secondaryText || "";
  const apcIsAmount =
    /\d/.test(apcHero) && !/not listed|no article|hybrid|subscription/i.test(apcHero);

  const licenses = (d?.licenses || []).filter((l) => l?.type);
  const subjects = subjectItems(d, o);
  const cited =
    o?.meanCitedness2yr != null ? Number(o.meanCitedness2yr).toFixed(2) : "—";

  const ui = globalThis.ScholarScopeUi;
  const openAccessBody = ui?.openAccessBody?.bind(ui);
  const subjectLine = ui?.subjectLine?.bind(ui);
  const indexingPublicationTile = ui?.indexingPublicationTile?.bind(ui);
  const otherFeesBlock = ui?.otherFeesBlock?.bind(ui);

  const oaHtml = openAccessBody
    ? openAccessBody(d, o, doajUrl, openAlexUrl, licenses, "ss")
    : `<p class="ss-prose ss-prose-muted">Access details unavailable.</p>`;
  const subjectsHtml = subjectLine
    ? subjectLine(subjects, "ss", 10)
    : `<p class="ss-prose ss-prose-muted">Subjects unavailable.</p>`;

  // Price click → page where that fee was sourced (DOAJ/OpenAlex/publisher fee page).
  const feeSource = data.apcDisplay?.feeSource || null;
  const apcUrl =
    data.apcDisplay?.sourceUrl ||
    data.publisherApc?.sourceUrl ||
    d?.apcUrl ||
    d?.oaStatementUrl ||
    data.otherFees?.feeUrl ||
    (feeSource === "doaj" ? doajUrl : null) ||
    (feeSource === "openalex" ? openAlexUrl : null) ||
    null;

  const bentoCtx = {
    doajUrl,
    scimagoUrl: data.scimagoUrl,
    openAlexUrl,
    issnUrl,
    indexingRows: data.indexing?.rows || [],
    publisherApcUrl:
      data.publisherApc?.sourceUrl || d?.apcUrl || d?.oaStatementUrl || null,
  };
  const indexTile = indexingPublicationTile
    ? indexingPublicationTile(d, o, bentoCtx, "ss")
    : "";
  const otherFeesHtml = otherFeesBlock
    ? otherFeesBlock(data.otherFees, "ss")
    : "";

  out.hidden = false;
  out.innerHTML = `
    <div class="out-card">
      <div class="eyebrow">Publishing brief</div>
      <h2>${href(journalUrl, data.title || "Journal", "a title-link")}</h2>
      <div class="meta">
        ${data.issn ? href(issnUrl, `ISSN ${data.issn}`, "a mono") : ""}
        ${href(publisherUrl, data.publisher || "Publisher unknown", "a")}
        <span class="freshness" role="status">
          <span class="freshness-dot ${data.cached ? "is-cached" : "is-live"}" aria-hidden="true"></span>
          ${data.cached ? "Cached" : "Live data"}
        </span>
      </div>
    </div>

    <div class="block block-fees">
      <div class="fees-bento">
        <article class="bento-tile bento-apc">
          <h4 class="bento-kicker">Article processing charge</h4>
          ${
            data.apcDisplay?.sourceBadge
              ? `<span class="apc-badge">${escapeHtml(data.apcDisplay.sourceBadge)}</span>`
              : ""
          }
          <div class="price-hero">
            ${
              apcIsAmount
                ? apcUrl
                  ? `<span class="apc-mount" data-ss-apc-shimmer data-apc-text="${escapeAttr(apcHero)}" data-apc-href="${escapeAttr(apcUrl)}" data-apc-class="a apc-amount"></span>`
                  : `<span class="apc-mount" data-ss-apc-shimmer data-apc-text="${escapeAttr(apcHero)}" data-apc-class="apc-amount"></span>`
                : `<p class="apc-message">${apcUrl ? href(apcUrl, apcHero, "a") : escapeHtml(apcHero)}</p>${
                    /not listed/i.test(apcHero)
                      ? `<p class="apc-hint">May be hybrid or subscription-only. Confirm on the publisher site.</p>`
                      : ""
                  }`
            }
          </div>
          ${
            apcSecondary
              ? `<p class="price-alt">Also listed: ${escapeHtml(apcSecondary)}</p>`
              : ""
          }
          ${apcLocalHtml(data)}
          ${
            data.apcDisplay?.sourceHint
              ? `<p class="apc-hint">${escapeHtml(data.apcDisplay.sourceHint)}</p>`
              : ""
          }
          ${
            apcIsAmount && apcUrl
              ? `<p class="apc-hint">Click the price to open the fee source page.</p>`
              : ""
          }
          ${otherFeesHtml}
        </article>
        <article class="bento-tile bento-index">
          ${indexTile}
        </article>
      </div>
    </div>

    <div class="block">
      <h3 class="section-head">Access &amp; license</h3>
      ${oaHtml}
    </div>

    <div class="block">
      <h3 class="section-head">Subjects</h3>
      ${subjectsHtml}
    </div>

    <div class="block">
      <h3 class="section-head">Impact metrics</h3>
      <div class="metrics">
        <a class="metric metric-link" href="${escapeAttr(openAlexUrl || data.scimagoUrl)}" target="_blank" rel="noopener noreferrer">
          <div class="metric-k">2yr mean citedness</div>
          <div class="metric-v">${escapeHtml(cited)}</div>
        </a>
        <a class="metric metric-link" href="${escapeAttr(openAlexUrl || data.scimagoUrl)}" target="_blank" rel="noopener noreferrer">
          <div class="metric-k">h-index</div>
          <div class="metric-v">${o?.hIndex != null ? escapeHtml(String(o.hIndex)) : "—"}</div>
        </a>
      </div>
    </div>

    <div class="links">
      <a class="primary" href="${escapeAttr(data.scimagoUrl)}" target="_blank" rel="noopener noreferrer">View SJR on SCImago</a>
      ${
        apcUrl
          ? `<a href="${escapeAttr(apcUrl)}" target="_blank" rel="noopener noreferrer">Publisher APC page</a>`
          : ""
      }
      ${
        journalUrl
          ? `<a href="${escapeAttr(journalUrl)}" target="_blank" rel="noopener noreferrer">Journal homepage</a>`
          : ""
      }
      ${
        openAlexUrl
          ? `<a href="${escapeAttr(openAlexUrl)}" target="_blank" rel="noopener noreferrer">OpenAlex record</a>`
          : ""
      }
      ${
        doajUrl
          ? `<a href="${escapeAttr(doajUrl)}" target="_blank" rel="noopener noreferrer">DOAJ record</a>`
          : ""
      }
    </div>

    <div class="note">${escapeHtml(data.labels?.impactNote || "")}</div>
  `;
  mountAllApcPrices(out);
}
